﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace pizzarendeles
{
    /// <summary>
    /// Interaction logic for Regisztracio.xaml
    /// </summary>
    public partial class Regisztracio : Window
    {
        public Regisztracio()
        {
            InitializeComponent();
        }

        private void btn_reg_user_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionString = "datasource=127.0.0.1;port=3306;username=db_user;password=admin;database=pizzarendeles;";

                string query = "CREATE USER '" + name_reg_txtbox.Text +"'@'localhost' IDENTIFIED BY '"+ pass_reg_txtbox.Text +"'; GRANT INSERT ON `pizzarendeles.test`.* TO '" + name_reg_txtbox.Text + "'@'localhost';";
                MySqlConnection databaseConnection = new MySqlConnection(connectionString);
                MySqlCommand myadat = new MySqlCommand(query, databaseConnection);
                myadat.CommandTimeout = 60;
                databaseConnection.Open();
                MessageBox.Show(query);
            }
            catch (Exception)
            {

                throw;
            }
            

        }
    }
}
