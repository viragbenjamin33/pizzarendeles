﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace pizzarendeles
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionString = "datasource=127.0.0.1;port=3306;username=" + name_txtbox.Text + ";password=" + pass_txtbox.Text + ";database=pizzarendeles;";

                string query = "SELECT * FROM test";
                MySqlConnection databaseConnection = new MySqlConnection(connectionString);
                MySqlCommand myadat = new MySqlCommand(query, databaseConnection);
                myadat.CommandTimeout = 60;

                databaseConnection.Open();
            }
            catch (MySql.Data.MySqlClient.MySqlException)
            {
                lb_error.Content = "Nincs ilyen felhasználó név és jelszó páros!";
            }
        }

        private void btn_reg_Click(object sender, RoutedEventArgs e)
        {
            Regisztracio reg = new Regisztracio();
            Visibility = Visibility.Hidden;
            reg.ShowDialog();
            Visibility = Visibility.Visible;
        }
    }
}
